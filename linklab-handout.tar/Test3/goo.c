extern int k;

void goo()
{
    k = 4;
}
