
void foo()
{
}
